<aside id="sidebar">

	<ul class="sidebar">
		<?php dynamic_sidebar('global_sidebar'); ?>
	</ul>
	<!-- /.sidebar -->

</aside>
<!-- /#sidebar -->